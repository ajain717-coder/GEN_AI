# GenAI App Deployment - Task 39

## Objective
Deploy a GenAI chatbot application using Streamlit Cloud and Hugging Face Spaces.

## Features
- Simple chatbot UI
- Model selection
- Clear chat option

## Files Included
- app.py
- requirements.txt
- README.md

## How to Run Locally
pip install -r requirements.txt
streamlit run app.py


## Deployment Links
- Streamlit Cloud: (add your link)
- Hugging Face: (add your link)

## Comparison

### Streamlit Cloud
- Easy to deploy
- Fast UI
- No GPU support

### Hugging Face Spaces
- Supports ML apps
- GPU available
- Slightly complex setup

## Conclusion
Streamlit is best for simple apps, Hugging Face is best for AI demos.

## Challenges Faced
- Deployment errors
- Dependency issues
- Fixing requirements.txt

